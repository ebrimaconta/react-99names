export { default as Slide } from './slide';
export { default as Fade } from './fade';
export { default as Zoom } from './zoom';
